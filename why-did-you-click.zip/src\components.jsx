import { ArrowRight, BrainCircuit, ChevronLeft, ShieldCheck, Trophy } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useGame } from './state/GameContext'

export function Logo() { return <Link to="/" className="font-display text-sm tracking-tight sm:text-base">WHY DID <span className="text-cyan">YOU CLICK?</span></Link> }
export function Shell({ children, compact = false }) { const { game } = useGame(); return <main className="grid-bg min-h-screen overflow-hidden"><header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6"><Logo /><div className="flex items-center gap-2"><span className="hidden pill text-cyan sm:block"><Trophy className="mr-1 inline h-3 w-3" />{game.score} MIL</span><Link className="pill hover:border-cyan" to="/teacher">For educators</Link></div></header>{children}</main> }
export function Progress({ current }) { return <div className="mx-auto mb-8 flex max-w-xl gap-1 px-5">{[1,2,3,4,5,6].map(n => <div key={n} className={'h-1.5 flex-1 rounded-full ' + (n <= current ? 'bg-cyan' : 'bg-white/10')} />)}</div> }
export function Button({ children, to, onClick, className = '' }) { const base = 'inline-flex items-center justify-center gap-2 rounded-xl bg-cyan px-5 py-3 font-bold text-ink hover:scale-[1.02] hover:bg-white ' + className; return to ? <Link className={base} to={to}>{children}<ArrowRight className="h-4 w-4" /></Link> : <button className={base} onClick={onClick}>{children}<ArrowRight className="h-4 w-4" /></button> }
export function Back() { const nav = useNavigate(); return <button onClick={() => nav(-1)} className="mb-5 inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"><ChevronLeft className="h-4 w-4" />Back</button> }
export function Stat({ icon: Icon, label, value, tone = 'cyan' }) { return <div className="card p-5"><Icon className={'mb-3 h-5 w-5 text-' + tone} /><p className="text-2xl font-bold">{value}</p><p className="text-xs uppercase tracking-widest text-slate-400">{label}</p></div> }
export const Icons = { BrainCircuit, ShieldCheck }
