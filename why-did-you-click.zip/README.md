# WHY DID YOU CLICK?

An interactive media-literacy game built with React, Vite, and Tailwind CSS. Learners investigate six realistic online scenarios, make choices, earn a media-literacy score, and receive a personalised report.

## Run it locally

1. Install [Node.js](https://nodejs.org/) (current LTS).
2. In this project folder, run `npm install`.
3. Run `npm run dev` and open the local link shown.

## Build for publishing

Run `npm run build`. The ready-to-host files are created in `dist/`.

## Publish on GitHub Pages

1. Create a new GitHub repository named `why-did-you-click`.
2. Upload this project or use Git:
   ```bash
   git init
   git add .
   git commit -m "Initial game release"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/why-did-you-click.git
   git push -u origin main
   ```
3. For simple hosting, use a service such as Netlify or Vercel and connect the repository. Set build command to `npm run build` and publish directory to `dist`.

## Customisation

- Change scenarios and answers in `src/data/levels.js`.
- Update colour and type design in `tailwind.config.js` and `src/styles.css`.
- Progress is intentionally stored in the browser, so no account or database is required.
