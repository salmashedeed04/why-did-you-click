import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const repository = process.env.GITHUB_REPOSITORY?.split('/')[1]

export default defineConfig({
  plugins: [react()],
  // GitHub Pages serves project sites from /repository-name/.
  base: process.env.GITHUB_ACTIONS && repository ? `/${repository}/` : '/',
})
