import { Navigate, Route, Routes } from 'react-router-dom'
import { Home, Game, Report, Challenge, Teacher } from './pages'
export default function App() { return <Routes><Route path="/" element={<Home />} /><Route path="/play/:id" element={<Game />} /><Route path="/report" element={<Report />} /><Route path="/challenge" element={<Challenge />} /><Route path="/teacher" element={<Teacher />} /><Route path="*" element={<Navigate to="/" replace />} /></Routes> }
