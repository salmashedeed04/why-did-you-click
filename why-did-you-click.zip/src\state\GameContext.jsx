import { createContext, useContext, useEffect, useMemo, useState } from 'react'

const GameContext = createContext()
const initial = { score: 0, choices: [], completed: [], alias: 'Detective' }
export function GameProvider({ children }) {
  const [game, setGame] = useState(() => JSON.parse(localStorage.getItem('wdcy-game') || 'null') || initial)
  useEffect(() => localStorage.setItem('wdcy-game', JSON.stringify(game)), [game])
  const value = useMemo(() => ({ game, answer(level, option) { setGame(g => ({ ...g, score: g.score + option.points, choices: [...g.choices, { level, ...option }], completed: [...new Set([...g.completed, level])] })) }, reset() { setGame(initial) }, setAlias(alias) { setGame(g => ({...g, alias})) } }), [game])
  return <GameContext.Provider value={value}>{children}</GameContext.Provider>
}
export const useGame = () => useContext(GameContext)
