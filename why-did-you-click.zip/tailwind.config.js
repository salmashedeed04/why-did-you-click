/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html', './src/**/*.{js,jsx}'], theme: { extend: { fontFamily: { display: ['Arial Black', 'Impact', 'sans-serif'] }, colors: { ink: '#070b19', panel: '#10172e', cyan: '#53e8ff', coral: '#ff6b80', lime: '#c8ff61' }, boxShadow: { neon: '0 0 32px rgba(83,232,255,.23)' } } }, plugins: [] }
